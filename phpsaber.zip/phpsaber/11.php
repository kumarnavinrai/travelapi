Origin:
LAX
Destination:
JFK
Departure date:
10/18/2016
Run workflow
Results
<pre class='xdebug-var-dump' dir='ltr'>
<small>C:\wamp\www\phpsaber\start_rest_workflow.php:11:</small>
<b>object</b>(<i>SharedContext</i>)[<i>3</i>]
  <i>private</i> 'results' <font color='#888a85'>=&gt;</font> 
    <b>array</b> <i>(size=7)</i>
      'SECURITY' <font color='#888a85'>=&gt;</font> <font color='#3465a4'>null</font>
      'origin' <font color='#888a85'>=&gt;</font> <small>string</small> <font color='#cc0000'>'LAX'</font> <i>(length=3)</i>
      'destination' <font color='#888a85'>=&gt;</font> <small>string</small> <font color='#cc0000'>'JFK'</font> <i>(length=3)</i>
      'departureDate' <font color='#888a85'>=&gt;</font> <small>string</small> <font color='#cc0000'>'2016-10-18'</font> <i>(length=10)</i>
      'LeadPriceCalendar' <font color='#888a85'>=&gt;</font> 
        <b>object</b>(<i>stdClass</i>)[<i>6</i>]
          <i>public</i> 'OriginLocation' <font color='#888a85'>=&gt;</font> <small>string</small> <font color='#cc0000'>'LAX'</font> <i>(length=3)</i>
          <i>public</i> 'DestinationLocation' <font color='#888a85'>=&gt;</font> <small>string</small> <font color='#cc0000'>'JFK'</font> <i>(length=3)</i>
          <i>public</i> 'FareInfo' <font color='#888a85'>=&gt;</font> 
            <b>array</b> <i>(size=1)</i>
              ...
          <i>public</i> 'Links' <font color='#888a85'>=&gt;</font> 
            <b>array</b> <i>(size=2)</i>
              ...
      'InstaFlight' <font color='#888a85'>=&gt;</font> 
        <b>object</b>(<i>stdClass</i>)[<i>15</i>]
          <i>public</i> 'PricedItineraries' <font color='#888a85'>=&gt;</font> 
            <b>array</b> <i>(size=50)</i>
              ...
          <i>public</i> 'ReturnDateTime' <font color='#888a85'>=&gt;</font> <small>string</small> <font color='#cc0000'>'2016-10-23'</font> <i>(length=10)</i>
          <i>public</i> 'DepartureDateTime' <font color='#888a85'>=&gt;</font> <small>string</small> <font color='#cc0000'>'2016-10-18'</font> <i>(length=10)</i>
          <i>public</i> 'DestinationLocation' <font color='#888a85'>=&gt;</font> <small>string</small> <font color='#cc0000'>'JFK'</font> <i>(length=3)</i>
          <i>public</i> 'OriginLocation' <font color='#888a85'>=&gt;</font> <small>string</small> <font color='#cc0000'>'LAX'</font> <i>(length=3)</i>
          <i>public</i> 'Links' <font color='#888a85'>=&gt;</font> 
            <b>array</b> <i>(size=2)</i>
              ...
      'BargainFinderMax' <font color='#888a85'>=&gt;</font> 
        <b>object</b>(<i>stdClass</i>)[<i>4</i>]
          <i>public</i> 'OTA_AirLowFareSearchRS' <font color='#888a85'>=&gt;</font> 
            <b>object</b>(<i>stdClass</i>)[<i>3863</i>]
              ...
          <i>public</i> 'Links' <font color='#888a85'>=&gt;</font> 
            <b>array</b> <i>(size=2)</i>
              ...
</pre>